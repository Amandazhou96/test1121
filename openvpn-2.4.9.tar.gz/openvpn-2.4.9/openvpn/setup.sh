#!/bin/bash

INSTALLMOD=$1
ADDRESS=$2

function dev() {
    cd rpm/x86_64
    yum -y localinstall ./* --setopt=protected_multilib=false
    cd - >> /dev/null
}

function pub() {
    cd rpm/x86_64
    yum -y localinstall ./* --setopt=protected_multilib=false
    cd - >> /dev/null
}

function remove() {
    rpm -aq |grep openvpn |xargs rpm -ev
}

function set_server_config() {
    tar zxvf config/server.tar.gz -C /etc/openvpn/
    sed -i "s/LOCALADDR/$ADDRESS/" /etc/openvpn/server/core-net.conf
}

function set_client_config() {
    tar zxvf config/client.tar.gz -C /etc/openvpn/
    sed -i "s/LOCALADDR/$ADDRESS/" /etc/openvpn/client/admin.ovpn
}

case $INSTALLMOD in
 dev)
	set -e
        echo "dev install start ..."
        dev
        set_server_config
        echo "install finish"
        ;;  
 pub)
	set -e
        echo "pub install start ..."
        pub
        set_server_config
        echo "install finish"
        ;;  
 client)
	set -e
        echo "client install start ..."
        pub
        set_client_config
        echo "install finish"
        ;;
 remove)
        echo "remove string ..."
        remove
        echo "remove finish"
        ;;
 *)
        echo "Usage: $name localaddress [dev|pub|client|remove]
Openvpn install script

Arguments
    localaddress    Fill in the local address
    dev             Eevelopment mode installation, include debuginfo
    pub             Publish mod installation, no includee debufinfo
    client          Install client
    remove          Remove openvpn in this machine"
        exit 1
        ;;  
esac
