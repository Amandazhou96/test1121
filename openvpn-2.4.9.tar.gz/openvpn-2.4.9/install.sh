#!/bin/bash

BASE_PATH=$(cd `dirname $0`; pwd)
# uncompress and install
local_ip=`ip addr | grep inet | grep -v inet6 | grep -v '127.0.0.1' | awk '{print $2}' | awk -F '/' '{print $1}'`
cd openvpn && sh setup.sh pub ${local_ip} && cd -

touch /var/log/das_openvpn.log

systemctl enable openvpn-server@core-net.service
systemctl daemon-reload
systemctl start openvpn-server@core-net.service

firewall-cmd --add-port=1194/udp --permanent
firewall-cmd --reload

# remove packages
rm -rf package.tar.gz openvpn

# clean bash history
if [ -f /root/.bash_history ]; then
    rm -f /root/.bash_history
fi
history -c
 
cd /
if [ -n "${BASE_PATH}" -a -d "${BASE_PATH}" ]; then
rm -rf "${BASE_PATH}"
fi
